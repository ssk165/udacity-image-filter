# Udagram Image Filtering Microservice

### Setup Node Enviornment

1. Initialize a new project: `npm i`
2. run the development server with `npm run dev`
